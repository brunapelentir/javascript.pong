//variáveis da Bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;
let raio = diametro / 2;

let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;

//variáveis da raquete
let xRaquete = 5;
let yRaquete = 150;
let raqueteComprimento = 10;
let raqueteAltura = 90;

let xRaquete2 = 585;
let yRaquete2 = 150;
let raqueteComprimento2 = 10;
let raqueteAltura2 = 90;

function mostraRaquete() {
    rect(xRaquete, yRaquete, raqueteComprimento, raqueteAltura);
}
function mostraRaquete2() {
    rect(xRaquete2, yRaquete2, raqueteComprimento2, raqueteAltura2);
}

function setup() {
    createCanvas(600, 400);
}
function draw() {
    background(0);
    mostraBolinha();
    movimentaBolinha();xRaquete
    verificaColisaoBorda();
    rect(xRaquete, yRaquete, raqueteComprimento, raqueteAltura);
    rect(xRaquete2, yRaquete2, raqueteComprimento2, raqueteAltura2);
    mostraRaquete()
    mostraRaquete2()
    movimentaMinhaRaquete();
  movimentaMinhaRaquete2();
   verificaColisaoRaquete()
}

function mostraBolinha() {
    circle(xBolinha, yBolinha, diametro)
}

function movimentaBolinha() {
    xBolinha += velocidadeXBolinha;
    yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda() {
    if (xBolinha + raio > width || xBolinha - raio < 0) {
        velocidadeXBolinha *= -1;
    }
    if (yBolinha + raio > height || yBolinha - raio < 0) {
        velocidadeYBolinha *= -1;
    }
}
function movimentaMinhaRaquete() {
    if (keyIsDown(UP_ARROW)) {
        yRaquete -= 10;
    }
    if (keyIsDown(DOWN_ARROW)) {
        yRaquete += 10;
    }
}
function verificaColisaoRaquete() {
    if (xBolinha - raio < xRaquete + raqueteComprimento
        && yBolinha - raio < yRaquete + raqueteAltura
        && yBolinha + raio > yRaquete) {
        velocidadeXBolinha *= -1;
    }
}
function movimentaMinhaRaquete2() {
    if (keyIsDown(LEFT_ARROW)) {
        yRaquete2 -= 10;
    }
    if (keyIsDown(RIGHT_ARROW)) {
        yRaquete2 += 10;
    }
}
function verificaColisaoRaquete2() {
    if (xBolinha - raio < xRaquete + raqueteComprimento
        && yBolinha - raio < yRaquete + raqueteAltura
        && yBolinha + raio > yRaquete) {
        velocidadeXBolinha *= -1;
    }
}